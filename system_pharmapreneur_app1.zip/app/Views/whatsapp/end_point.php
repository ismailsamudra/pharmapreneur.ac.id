<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a id="b_keluar"></a>
            <h5><small><i class="fab fa-whatsapp mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-12 my-2">
                <div id="notif" class="mb-2"></div>
                <div class="row">

                    <div class="col-md-6 col-12">
                        <div class="card table-responsive">
                            <div class="form-control">
                                <span id="sta"></span>
                            </div>
                        </div>
                        <div id="lb_nmwa"></div>
                        <div id="lb_nowa"></div>
                    </div>
                    <div class="col-md-6 col-12">
                        <div class="my-2" id="gfo">
                            <center>
                                <h3 id="qrcode"></h3>
                            </center>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    HARAP RAHASIAKAN HALAMAN INI
                                    <a id="btn_test"></a>
                                </x>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>STATUS</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="wa_status" id="wa_status1" onclick="status('wa_status','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="wa_status" id="wa_status2" onclick="status('wa_status','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>URL ENDPOINT</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="wa_endpoint_lb"><strong><?= inc('wa_endpoint'); ?></strong></div>
                                    <input type="text" id="wa_endpoint" style="height: 23px;" value="<?= inc('wa_endpoint') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_wa_endpoint" class="float-right" onclick="pass_e('wa_endpoint')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_wa_endpoint" class="float-right" onclick="save('wa_endpoint')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>URL CALLBACK</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="wa_callback_lb"><strong><?= inc('wa_callback'); ?></strong></div>
                                    <input type="text" id="wa_callback" style="height: 23px;" value="<?= inc('wa_callback') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_wa_callback" class="float-right" onclick="pass_e('wa_callback')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_wa_callback" class="float-right" onclick="save('wa_callback')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>API-KEY</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="wa_key_lb"><strong><?= inc('wa_key'); ?></strong></div>
                                    <input type="text" id="wa_key" style="height: 23px;" value="<?= inc('wa_key') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_wa_key" class="float-right" onclick="pass_e('wa_key')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_wa_key" class="float-right" onclick="save('wa_key')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="test" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fab fa-whatsapp mr-2"></i>KIRIM WHATSAPP</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <small>KEPADA</small>
                <input type="text" class="form-control" placeholder="No.Whatsapp" id="to">
                <small>PESAN</small>
                <textarea name="msg" id="msg" class="form-control" rows="4"></textarea>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="send()" class="btn btn-outline-dark btn-sm"><i class="far fa-paper-plane mr-2"></i>Kirim</a>
            </div>
        </div>

    </div>
</div>
</div>
<!-- End Modal 1-->
<input type="hidden" id="class_id">
<script type="text/javascript">
    //===========================================
    get_sta();
    setInterval(get_sta, 3000);

    function get_sta() {
        $.get("<?= XROOT ?>whatsapp/status", function(data) {
            if (data.ready) {
                $("#apik").html('');
                $("#btn_test").html('<a href="javascript:void(0);" onclick="test();" class="float-right pri-b">TES KIRIM</a>');
                $("#sta").html('<small><strong class="text-success">Whatsapp Terhubung<i class="fa fa-check text-success ml-2"></i></strong></small>');
                $("#qrcode").empty();
                $("#qrcode").html('<img src="<?= XROOT ?>img/dev/wa.gif" width="60%">');
                // $("#b_keluar").html('');
                $("#b_keluar").html('<a href="javascript:void(0)" onclick="keluar();" class="btn-sm bt-1 float-left" title="Keluar"><i class="fa fa-power-off"></i></a>');
                $("#notif").html('<small><strong class="pri-c">NB : Pastikan DEVICE Selalu nyala dan terkoneksi dengan internet.</strong></small>');
                $.get("<?= XROOT ?>whatsapp/me_data", function(me) {
                    $("#lb_nmwa").html(`
                       <div class="card col table-responsive my-1">
                            <div class="row">
                                <div class="col-md-4">
                                    Nama 
                                </div>
                                <div class="col-md-8">
                                  :  ` + me.name + `
                                </div>
                            </div>
                        </div>
                    `);
                    $("#lb_nowa").html(`
                        <div class="card col table-responsive my-1">
                            <div class="row">
                                <div class="col-md-4">
                                        No.Whatsapp
                                </div>
                                <div class="col-md-8">
                                    : ` + me.number + `
                                </div>
                            </div>
                        </div>
                    `);
                }, 'json');
            } else if (data.not_ready) {
                $("#btn_test").html('');
                $("#lb_nmwa").html('');
                $("#lb_nowa").html('');
                $("#notif").html('<small><strong class="pri-c">NB : Harap Menunggu Setelah Scan Berhasil ,Aksi ini Membutuhkan waktu Tergantung jaringan dan Respon dari server.</strong></small>');
                $("#sta").html('<small><strong>Silahkan Scan Qrcode</strong></small>');
                $("#b_keluar").html('');
                get_qr();
            } else if (data.no_internet) {
                $("#btn_test").html('');
                $("#lb_nmwa").html('');
                $("#lb_nowa").html('');
                $("#notif").html('');
                $("#load").modal('hide');
                $("#test").modal('hide');
                $("#sta").html('<small><strong>Device/Hp No internet</strong></small>');
                $("#qrcode").html('<img src="<?= XROOT ?>img/dev/loading.gif" width="60%">');
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            } else {
                $("#btn_test").html('');
                $("#lb_nmwa").html('');
                $("#lb_nowa").html('');
                $("#notif").html('');
                $("#sta").html('<small><strong class="text-danger">Server Disconected <i class="fa fa-times text-danger ml-2"></i></strong></small>');
                $("#qrcode").empty();
                $("#qrcode").html('<img src="<?= XROOT ?>img/dev/dis.png" width="60%">');
                $("#b_keluar").html('');
            }
        }, 'json');
    }

    function keluar() {
        $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Logout dari Whatsapp bot ?', function(r) {
            if (r) {
                $.get("<?= XROOT ?>whatsapp/logout", function(result) {
                    if (result.success) {
                        $("#keluar").modal('hide');
                        $.messager.show({ // show error message
                            title: 'Success',
                            msg: 'Berhasil Keluar'
                        });
                    } else {
                        $.messager.show({ // show error message
                            title: 'Error !',
                            msg: (result.errorMsg) ? result.errorMsg : "Server Restar"
                        });
                    }
                });
            }
        });
    }
    // $('#msg').summernote({
    //     height: 180,
    //     // themes:paper,
    //     airMode: false
    // })
    var wa_status = "<?= inc('wa_status') ?>";
    if (wa_status == 'true') {
        document.getElementById('wa_status2').checked = false;
        document.getElementById('wa_status1').checked = true;
    } else {
        document.getElementById('wa_status1').checked = false;
        document.getElementById('wa_status2').checked = true;
    }
    //---------------------------
    $('#wa_endpoint_lb').show();
    $('#wa_endpoint').hide();
    $('#bt_s_wa_endpoint').hide();
    $('#bt_e_wa_endpoint').show();
    //---------------------------
    //---------------------------
    $('#wa_callback_lb').show();
    $('#wa_callback').hide();
    $('#bt_s_wa_callback').hide();
    $('#bt_e_wa_callback').show();
    //---------------------------
    //---------------------------
    $('#wa_key_lb').show();
    $('#wa_key').hide();
    $('#bt_s_wa_key').hide();
    $('#bt_e_wa_key').show();
    //---------------------------
    //===========================================
    function test() {
        document.getElementById('to').value = '';
        // $('#msg').summernote('code', '');
        $('#test').modal('show');
    }

    function send() {
        var to = document.getElementById('to').value;
        if (to == '') {
            $("#to").focus();
            $.messager.show({ // show error message
                title: 'Error !',
                msg: 'No.Whatsapp Harus di isi'
            });
            exit;
        }
        var msg = document.getElementById('msg').value;
        if (msg == '') {
            $("#msg").focus();
            $.messager.show({ // show error message
                title: 'Error !',
                msg: 'Pesan Harus di isi'
            });
            exit;
        }
        $("#load").modal({
            backdrop: "static"
        });
        var url = '<?= XROOT ?>whatsapp/send';
        $.post(url, {
            to,
            msg
        }, function(result) {
            if (result.success) {
                $('#test').modal('hide');
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Kirim.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
            $("#load").modal('hide');
        }, 'json');
    }
    //===========================================
    //===========================================
    function pass_e(id) {
        $('#bt_e_' + id).hide();
        $('#bt_s_' + id).show();
        $('#' + id + '_lb').hide();
        $('#' + id).show();
        $('#' + id).focus();
    }
    //===========================================
    //===========================================
    function save(id) {
        var val = document.getElementById(id).value;
        var url = '<?= XROOT ?>inc/save_text';
        $.post(url, {
            id,
            val
        }, function(result) {
            if (result.success) {
                document.getElementById(id + '_lb').innerHTML = '<strong>' + val + '</strong>';
                $('#' + id).hide();
                $('#' + id + '_lb').show();
                $('#bt_s_' + id).hide();
                $('#bt_e_' + id).show();
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    function status(id, act) {
        var url = '<?= XROOT ?>inc/status2';
        $.post(url, {
            id,
            act
        }, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Status berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    $('#to').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>
<script src="<?= XROOT ?>script/qr-code-styling.js"></script>
<script src="<?= XROOT ?>script/show_qr.js"></script>
<script>
    function get_qr() {
        $.get("<?= XROOT ?>whatsapp/qrcode", function(data) {
            $("#qrcode").empty();
            var data = data.data.qr;
            var logo = "<?= XROOT ?>img/dev/wa_n.png";
            var color = "<?= color('qrcode-a') ?>";
            qrcode("qrcode", data, logo, color, '0');

        }, 'json');
    }
</script>