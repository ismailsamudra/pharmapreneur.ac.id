<section id="slider" class="slider">
    <div class="slider_overlay">
        <div class="container">
            <div class="row">
                <div class="main_slider text-center">
                    <div class="col-md-12">
                        <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                            <h1 style="font-family: '<?= inc('web_home_text_font'); ?>', cursive;color:<?= inc('web_home_text_color') ?>;-webkit-text-stroke-color: <?= inc('web_home_text_line_color') ?>;"><?= inc('web_home_judul') ?></h1>
                            <p style="font-family: '<?= inc('web_home_text_font'); ?>', cursive;color:<?= inc('web_home_text_color') ?>;-webkit-text-stroke-color: <?= inc('web_home_text_line_color') ?>;"><strong><?= inc('web_home_desk') ?></strong></p>
                            <!-- <button href="" class="btn-lg">Click here</button> -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>


<section id="abouts" class="abouts">
    <div class="container">
        <div class="row">
            <div class="abouts_content">
                <div class="col-md-6">
                    <div class="footer_socail_icon">
                        <div class="single_abouts_text text-center wow slideInLeft" data-wow-duration="1s">
                            <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="" width="200" />
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="single_abouts_text wow slideInRight" data-wow-duration="1s">
                        <h4>Tentang Kami</h4>
                        <h3><?= inc('web_home_tentang_judul') ?></h3>
                        <div style="color:black;">
                            <p><?= inc('web_home_tentang_desk') ?></p>
                        </div>

                        <!-- <a href="" class="btn btn-primary">click here</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $gl = db('web_gallery')->orderBy('id', 'DESC')->limit('1')->getWhere(['status' => 'true'])->getRow(); ?>
<style>
    .actf {
        background: url(<?= XROOT . 'img/web/gallery/' . $gl->img ?>) center center no-repeat;
        background-size: cover;
    }
</style>
<section id="actf" class="actf">
    <div class="slider_overlay">
        <div class="container">
            <div class="row">
                <div class="main_slider text-center">
                    <div class="col-md-12">
                        <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                            <h5 style="font-family: '<?= $gl->font ?>', cursive;color:<?= $gl->text_color ?>;-webkit-text-stroke-color: <?= $gl->line_color ?>;">KEGIATAN TERBARU</h5>
                            <h1 style="font-family: '<?= $gl->font ?>', cursive;color:<?= $gl->text_color ?>;-webkit-text-stroke-color: <?= $gl->line_color ?>;"><?= $gl->judul ?></h1>
                            <p style="font-family: '<?= $gl->font ?>', cursive;color:<?= $gl->text_color ?>;-webkit-text-stroke-color: <?= $gl->line_color ?>;"><strong><?= $gl->desk ?></strong></p>
                            <p style="color:<?= $gl->text_color ?>;"><i class="fa fa-calendar mr-2"></i> <strong><?= $gl->at_create ?></strong></p>
                            <!-- <button href="" class="btn-lg">Click here</button> -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<section id="portfolio" class="portfolio">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="head_title text-center">
                    <h4>Tenant Unggulan</h4>
                </div>
            </div>
            <?php $dt = db('produk_data')->getWhere(['status' => 'true', 'unggul' => 'Y'])->getResult(); ?>
            <?php foreach ($dt as $x) : ?>
                <div class="col-md-3 mrg">
                    <a href="<?= $x->url ?>">
                        <center>
                            <?php
                            if ($x->new == 'Y') {
                                echo '<div class="ribbon ribbon-top-right">
                                    <span>NEW</span>
                                </div>';
                            }
                            ?>
                            <img src="<?= XROOT ?>img/web/produk/<?= $x->img ?>" alt="" />
                        </center>
                        <h7>
                            <center><?= $x->nama ?></center>
                        </h7>
                    </a>
                </div>
            <?php endforeach ?>

        </div>
    </div>
    </div>
    </div>
</section>