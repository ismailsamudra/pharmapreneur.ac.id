<!-- BODY START ----------------------------------------------------------->
<div class="container">
    <?php
    $content = db('web_other')->getWhere(['id' => $id], 1)->getRow()->content;
    echo $content;
    ?>
</div>
<!-- BODY END ------------------------------------------------------------->
<br><br>