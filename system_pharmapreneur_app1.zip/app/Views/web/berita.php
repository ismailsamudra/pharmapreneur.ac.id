<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">BERI</span>TA</h2>
            <p class="large"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>
<style>
    .round {
        border-radius: 10px;
    }

    .bot {
        position: absolute;
        bottom: 0;
        left: 0;
    }

    .dt:hover .arr,
    .dt:hover {
        background-color: #dce2fc;
    }

    .arr {
        color: <?= color('primary-a'); ?>;
    }
</style>
<div class="section layout_padding">
    <div class="container">
        <?php $berita = db('web_berita')->orderBy('id', 'DESC')->getWhere(['status' => 'true'])->getResult(); ?>
        <?= (!$berita) ? '<center><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>' : ''; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <?php foreach ($berita as $o) : ?>
                        <?php (empty($o->img)) ? $img = 'default1.png' : $img = $o->img; ?>
                        <div class="col-md-4 my-2">
                            <div class="card dt">
                                <div class="m-1">
                                    <div class="row g-0">
                                        <div class="col-12">
                                            <img class="img-responsive my-2 round" src="<?= XROOT ?>img/web/berita/<?= $img ?>" alt="#" />
                                            <div class="ribbon"><a href="<?= XROOT ?>web/berita/<?= en64($o->id) ?>" class="m-2" title="Selengkapnya">Selengkapnya<i class="fa fa-sign-out-alt ml-2"></i></a></div>
                                        </div>
                                        <div class="col-12">
                                            <?= $o->judul ?><br>
                                            <small>Time Post : <?= $o->time ?></small> <br>
                                            <small>View : <?= $o->view ?></small><br>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endforeach ?>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- BODY END ------------------------------------------------------------->