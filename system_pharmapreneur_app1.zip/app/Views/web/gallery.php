<?php $gl = db('web_gallery')->orderBy('id', 'DESC')->getWhere(['status' => 'true'])->getResult(); ?>
<?php foreach ($gl as $o) : ?>
    <style>
        .actf<?= $o->id ?> {
            background: url(<?= XROOT . 'img/web/gallery/' . $o->img ?>) center center no-repeat;
            background-size: cover;
        }
    </style>
    <section id="actf<?= $o->id ?>" class="actf<?= $o->id ?>">
        <div class="slider_overlay">
            <div class="container">
                <div class="row">
                    <div class="main_slider text-center">
                        <div class="col-md-12">
                            <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                                <h1 style="font-family: '<?= $o->font ?>', cursive;color:<?= $o->text_color ?>;-webkit-text-stroke-color: <?= $o->line_color ?>;"><?= $o->judul ?></h1>
                                <p style="font-family: '<?= $o->font ?>', cursive;color:<?= $o->text_color ?>;-webkit-text-stroke-color: <?= $o->line_color ?>;"><strong><?= $o->desk ?></strong></p>
                                <!-- <p style="color:<?= $o->text_color ?>;"><i class="fa fa-calendar mr-2"></i> <strong><?= $o->at_create ?></strong></p> -->
                                <!-- <button href="" class="btn-lg">Click here</button> -->
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php endforeach ?>