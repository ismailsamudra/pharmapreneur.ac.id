   <section id="footer_widget" class="footer_widget">
       <div class="container">
           <div class="row">
               <div class="footer_widget_content text-center">
                   <div class="col-md-4">
                       <div class="single_widget wow fadeIn" data-wow-duration="2s">
                           <h3>Alamat</h3>

                           <div class="single_widget_info">
                               <p><?= inc('alamat') ?>
                               </p>
                           </div>

                           <div class="footer_socail_icon">
                               <?php
                                if (inc('url_facebook') != null) {
                                    echo '<a href="' . inc('url_facebook') . '" target="_blank"><i class="fa fa-facebook"></i></a>';
                                }
                                if (inc('url_instagram') != null) {
                                    echo '<a href="' . inc('url_instagram') . '" target="_blank"><i class="fa fa-instagram"></i></a>';
                                }
                                if (inc('url_whatsapp') != null) {
                                    echo '<a href="' . inc('url_whatsapp') . '" target="_blank"><i class="fa fa-whatsapp"></i></a>';
                                }
                                ?>
                           </div>
                       </div>
                   </div>

                   <div class="col-md-4">
                       <div class="single_widget wow fadeIn" data-wow-duration="4s">
                           <h3>Email</h3>

                           <div class="single_widget_info">
                               <p><span class="date_day"><?= inc('email') ?></span>
                               </p>
                           </div>
                       </div>
                   </div>

                   <div class="col-md-4">
                       <div class="single_widget wow fadeIn" data-wow-duration="5s">
                           <h3>Telp / Fax</h3>
                           <div class="single_widget_info">
                               <p><span class="date_day"><?= inc('telp') ?></span>
                               </p>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </section>
   <!--Footer-->
   <footer id="footer" class="footer">
       <div class="container text-center">
           <div class="row">
               <div class="col-sm-12">
                   <div class="copyright wow zoomIn" data-wow-duration="3s">
                       <p><a href="<?= XROOT ?>"><?= inc('nama-instansi') ?></a><?= date("Y") ?>. All Rights Reserved</p>
                   </div>
               </div>
           </div>
       </div>
   </footer>

   <div class="scrollup">
       <a href="#"><i class="fa fa-chevron-up"></i></a>
   </div>


   <script src="<?= XROOT ?>script/web2/js/vendor/jquery-1.11.2.min.js"></script>
   <script src="<?= XROOT ?>script/web2/js/vendor/bootstrap.min.js"></script>

   <script src="<?= XROOT ?>script/web2/js/jquery-easing/jquery.easing.1.3.js"></script>
   <script src="<?= XROOT ?>script/web2/js/wow/wow.min.js"></script>
   <script src="<?= XROOT ?>script/web2/js/plugins.js"></script>
   <script src="<?= XROOT ?>script/web2/js/main.js"></script>
   </body>
   <style>
       .widget-whatsapp {
           position: fixed;
           bottom: 90px;
           right: 50px;
           font-size: 40px;
           -webkit-border-radius: 999px;
           -moz-border-radius: 999px;
           border-radius: 999px;
           width: 60px;
           height: 60px;
           text-align: center;
           z-index: 1999;

       }
   </style>
   <?php
    if (inc('url_whatsapp') != null) {
        echo '<div class="widget-whatsapp">
    <a target="_blank" class="text-white" href="' . inc('url_whatsapp') . '">
        <img src="' . XROOT . 'img/dev/wa.gif" style="margin: left 10px;" alt="" width="80" title="Whatsapp Kami" />

    </a>
</div>';
    }
    ?>

   </html>