<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">

    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/bootstrap.min.css">
    <link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/font-awesome.min.css">
    <!--        <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/bootstrap-theme.min.css">-->


    <!--For Plugins external css-->
    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/animate/animate.css" />
    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/plugins.css" />

    <!--Theme custom css -->
    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/style.css">

    <!--Theme Responsive css-->
    <link rel="stylesheet" href="<?= XROOT ?>script/web2/css/responsive.css" />

    <script src="<?= XROOT ?>script/web2/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <?php $ff = db('temp_font')->get()->getResult(); ?>
    <?php foreach ($ff as $f) : ?>
        <style>
            @font-face {
                font-family: '<?= $f->font ?>';
                src: url('<?= XROOT ?>file/font/<?= $f->font ?>');
            }
        </style>
    <?php endforeach ?>
</head>

<body>
    <header id="home" class="navbar-fixed-top">

        <!-- End navbar-collapse-->
        <div class="main_menu_bg">
            <div class="line-t"></div>
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>

                                <a class="navbar-brand our_logo" href="#">
                                    <div class="card">
                                        <div class="row">
                                            <div class="col-6">
                                                <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="" width="70" />
                                            </div>
                                            <div class="col-6">
                                                <h5><?= inc('app-name') ?></h5>
                                                <span><small><small><?= inc('app-name-2') ?></small></small></span>
                                                <div class="line-s"></div>
                                            </div>
                                        </div>
                                    </div>

                                </a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <!-- <div class="card bg-dark">.</div> -->
                                <?php
                                $ses = session()->get('page');
                                $home = ($ses == 'home') ? "active" : "";
                                $gallery = ($ses == 'gallery') ? "active" : "";
                                $produk = ($ses == 'produk') ? "active" : "";
                                ?>
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="<?= XROOT ?>">
                                            <h5 class="<?= $home ?>">Home</h5>
                                        </a></li>
                                    <li><a href="<?= XROOT ?>web/gallery">
                                            <h5 class="<?= $gallery ?>">Gallery</h5>
                                        </a></li>
                                    <?php $dr = db('produk_kategori')->getWhere(['status' => 'true'])->getResult(); ?>
                                    <?php
                                    if ($ses != 'produk') {
                                        echo '<li><a href="' . XROOT . 'web/produk">
                                        <h5>Tenant</h5>
                                    </a></li>';
                                    } else {
                                        echo '
                                        <li>
                                        <div class="dropdown">
                                            <h5 style="color: #e7a331;" style="color:black;">Tenant</h5>
                                            <div class="dropdown-child">';
                                        foreach ($dr as $d) {
                                            echo '<a href="#' . $d->id . '">
                                                    <h5>' . $d->nama . '</h5>
                                                </a>';
                                        }

                                        echo '</div>
                                        </div>
                                    </li>
                                        ';
                                    }
                                    ?>

                                    <li><a href="<?= XROOT ?>login">
                                            <h5>Login</h5>
                                        </a></li>

                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav>
                </div>
            </div>
        </div>
    </header> <!-- End Header Section -->