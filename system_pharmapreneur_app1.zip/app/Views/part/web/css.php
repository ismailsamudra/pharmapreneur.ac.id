<style>
    html,
    body {
        background-color: <?= color('primary-a'); ?>;
        font-size: 15px;
        color: #22B85700;
        width: 100%;
        padding: 0;
        margin-left: 0;
        margin-right: 0;
        font-family: 'roboto', sans-serif;
        font-weight: 300;
    }

    .card {
        /* Add shadows to create the "card" effect */
        margin-top: 0;
        padding: 6px;
        /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); */
        background-color: <?= color('primary-a'); ?>;
        transition: 0.3s;
        color: <?= color('primary-b'); ?>;
        text-align: center;
        border-bottom-right-radius: 30px;
    }

    .active {
        color: #e7a331;
    }

    .mrg {
        margin-bottom: 50px;
    }

    .mrg img {
        background-size: cover;
        margin-bottom: 10px;
    }

    .line-t {
        /* Add shadows to create the "card" effect */
        width: 100%;
        height: 8px;
        background-color: <?= color('primary-a'); ?>;
        transition: 0.3s;
    }

    .footer {
        background: <?= color('primary-a'); ?>;
    }

    .footer_widget_content {
        color: <?= color('primary-b'); ?>;
    }

    .slider {
        background: url(<?= XROOT . 'img/instansi/' . inc('web_home_img') ?>) center center no-repeat;
        background-size: cover;
    }

    .slider_produk {
        background: url(<?= XROOT . 'img/instansi/' . inc('web_produk_img') ?>) center center no-repeat;
        -moz-background-size: cover;
        -webkit-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        width: 100%;
        height: 60;
    }

    /* Add shadows to create the "card" effect */
    /* .line-s {
                width: 80%;
                height: 2px;
                background-color: white;
                transition: 0.3s;
                margin-left: 10%;
            } */

    .dropdown {
        /* position: relative; */
        padding: 5px 10px;
        margin-top: 9px;
        display: inline-block;
        text-align: center;
    }

    .dropdown-child {
        display: none;
        background-color: white;
        margin-left: 10px;
        margin-right: 10px;
        /* min-width: 160px; */
    }

    .dropdown-child a {
        color: black;
        padding: 10px;
        text-decoration: none;
        display: block;
    }

    .dropdown-child a:hover {
        color: #e7a331;
    }

    .dropdown:hover .dropdown-child {
        display: block;
    }

    .box {
        position: relative;
        max-width: 600px;
        width: 90%;
        height: 400px;
        background: #fff;
        box-shadow: 0 0 15px rgba(0, 0, 0, .1);
    }

    /* common */
    .ribbon {
        width: 100px;
        height: 100px;
        overflow: hidden;
        position: absolute;
    }

    .ribbon::before,
    .ribbon::after {
        position: absolute;
        z-index: -1;
        content: '';
        display: block;
        border: 5px solid #2980b9;
    }

    .ribbon span {
        position: absolute;
        display: block;
        width: 110px;
        padding: 4px 0;
        background-color: <?= color('secondary-a') ?>;
        box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
        color: #fff;
        /* font: 700 18px/1 'Lato', sans-serif; */
        text-shadow: 0 1px 1px rgba(0, 0, 0, .2);
        text-transform: uppercase;
        text-align: center;
    }

    /* top left*/
    .ribbon-top-left {
        top: -10px;
        left: -10px;
    }

    .ribbon-top-left::before,
    .ribbon-top-left::after {
        border-top-color: transparent;
        border-left-color: transparent;
    }

    .ribbon-top-left::before {
        top: 0;
        right: 0;
    }

    .ribbon-top-left::after {
        bottom: 0;
        left: 0;
    }

    .ribbon-top-left span {
        right: -25px;
        top: 30px;
        transform: rotate(-45deg);
    }

    /* top right*/
    .ribbon-top-right {
        top: -10px;
        right: -10px;
    }

    .ribbon-top-right::before,
    .ribbon-top-right::after {
        border-top-color: transparent;
        border-right-color: transparent;
    }

    .ribbon-top-right::before {
        top: 0;
        left: 0;
    }

    .ribbon-top-right::after {
        bottom: 0;
        right: 0;
    }

    .ribbon-top-right span {
        left: -25px;
        top: 30px;
        transform: rotate(45deg);
    }

    /* bottom left*/
    .ribbon-bottom-left {
        bottom: -10px;
        left: -10px;
    }

    .ribbon-bottom-left::before,
    .ribbon-bottom-left::after {
        border-bottom-color: transparent;
        border-left-color: transparent;
    }

    .ribbon-bottom-left::before {
        bottom: 0;
        right: 0;
    }

    .ribbon-bottom-left::after {
        top: 0;
        left: 0;
    }

    .ribbon-bottom-left span {
        right: -25px;
        bottom: 30px;
        transform: rotate(225deg);
    }

    /* bottom right*/
    .ribbon-bottom-right {
        bottom: -10px;
        right: -10px;
    }

    .ribbon-bottom-right::before,
    .ribbon-bottom-right::after {
        border-bottom-color: transparent;
        border-right-color: transparent;
    }

    .ribbon-bottom-right::before {
        bottom: 0;
        left: 0;
    }

    .ribbon-bottom-right::after {
        top: 0;
        right: 0;
    }

    .ribbon-bottom-right span {
        left: -25px;
        bottom: 30px;
        transform: rotate(-225deg);
    }

    .footer_socail_icon a i {
        font-size: 25px;
        color: <?= color('primary-b') ?>;
    }

    /* FONT STYLE START */
    @font-face {
        font-family: '<?= inc('font_web_global'); ?>';
        src: url('<?= XROOT ?>file/font/<?= inc('font_web_global'); ?>');
    }

    h4 {
        font-size: 1.875rem;
        line-height: 2.2rem;
        margin-bottom: 1.1rem;
        font-family: '<?= inc('font_web_global'); ?>', cursive;

    }

    h5 {

        font-weight: 300;
        margin: 0;
        line-height: 2rem;
        font-family: '<?= inc('font_web_global'); ?>', cursive;

    }

    h6 {
        font-size: 4rem;
        font-family: '<?= inc('font_web_global'); ?>', cursive;
        color: #fff;
        line-height: 6rem;
        margin: 0px 0px 60px 0px;
        -webkit-text-stroke-width: 2px;
    }

    h7 {
        font-size: 1.2rem;
        font-family: '<?= inc('font_web_global'); ?>', cursive;
        color: black;
    }

    .ourPakeg .main_pakeg_content .head_title h4 {
        color: #fff;
        font-family: '<?= inc('font_web_global'); ?>', cursive;
        font-size: 1.875rem;
    }

    .single_widget h3 {
        font-size: 1.875rem;

        font-family: '<?= inc('font_web_global'); ?>', cursive;
    }

    /* FONT STYLE END */
    /* SLIDER STYLE START */
    /* .main_slider {} */

    .main_slider .main_slider_content h1 {
        font-size: 4rem;
        font-family: '<?= inc('font_web_global'); ?>', cursive;
        color: #fff;
        line-height: 6rem;
        margin: 0px 0px 60px 0px;
        -webkit-text-stroke-width: 2px;
    }

    .main_slider .main_slider_content p {
        font-size: 1.3rem;
        -webkit-text-stroke-width: 0.1px;
    }

    .main_slider_content {
        padding: 250px 0px 200px 0px;
        width: 70%;
        margin: 0 auto;
        color: #fff;
    }

    .slider_overlay {
        /* background:rgba(0, 0, 0, .6); */
        width: 100%;
        top: 0;
        left: 0;
    }

    @media only screen and (max-width: 600px) {

        .main_slider .main_slider_content h1 {
            font-size: 2rem;
            line-height: 3rem;
            margin: 0px 0px 6px 0px;
            -webkit-text-stroke-width: 0.05rem;
        }

        .main_slider .main_slider_content p {
            font-size: 1rem;
            -webkit-text-stroke-width: 0.02rem;
        }

        h6 {
            font-size: 2rem;
            line-height: 3rem;
            margin: 0px 0px 6px 0px;
            -webkit-text-stroke-width: 0.05rem;
        }

        .main_slider_content {
            /* padding: 250px 0px 200px 0px; */
            width: 90%;
            margin: 0 auto;
            color: #fff;
        }
    }

    /* SLIDER STYLE END */
</style>