<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-asymmetrik mr-2"></i> <?= strtoupper('master Font') ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">
    <?php $ff = db('temp_font')->get()->getResult(); ?>
    <?php foreach ($ff as $f) : ?>
        <style>
            @font-face {
                font-family: '<?= $f->font ?>';
                src: url('<?= XROOT ?>file/font/<?= $f->font ?>');
            }
        </style>
    <?php endforeach ?>
    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                FONT WEB GLOBAL
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>FONT AKTIF</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="font_web_global_lb" style="font-family: '<?= inc('font_web_global'); ?>', cursive;font-size: 1.2rem;"><strong><?= inc('font_web_global'); ?></strong></div>
                                    <select name="font_web_global" id="font_web_global" class="form-control">
                                        <option style="font-family: '<?= inc('font_web_global'); ?>', cursive;font-size: 1.2rem;" value="<?= inc('font_web_global') ?>"><?= inc('font_web_global') ?></option>
                                        <?php foreach ($ff as $f) : ?>
                                            <option value="<?= $f->font ?>" style="font-family: '<?= $f->font ?>', cursive;font-size: 1.2rem;"><?= $f->font ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_font_web_global" class="float-right" onclick="pass_e('font_web_global')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_font_web_global" class="float-right" onclick="save('font_web_global')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                MASTER FONT
                            </strong>
                        </small>
                        <a href="javascript:void(0);" id="" class="float-right" onclick="add()"><i class="fa fa-plus" style="color: <?= color('primary-b') ?>;" title="Add"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <?php foreach ($ff as $f) : ?>

                    <div class="row mb-2">
                        <div class="col-md-4">
                            <div class="card col table-responsive">
                                <small><strong><?= $f->font ?></strong></small>
                                <a href="javascript:void(0);" class="float-right" onclick="hapus('<?= $f->font ?>')"><i class="fa fa-trash text-danger" title="Hapus"></i></a>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card col table-responsive">
                                <div class="row col">
                                    <label for="" style="font-family: '<?= $f->font ?>', cursive;font-size: 2rem;"> ABCDEFGHIJ abcdefghij</label>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach ?>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <small id="lb_id">UPLOAD Font [ Wajib Format ttf,otf]</small>
                    <input type="file" name="file" id="file" class="form-control">
                </form>
                <div class="container">
                    <div class="text-dark">
                        <br>
                        <strong>
                            NB :
                        </strong>
                        <br>
                        <small>
                            Saran Link Download Untuk Font : <br>
                            <a href="https://www.dafont.com/" target="_blank">https://www.dafont.com/</a> <br>
                            <a href="https://www.fontspace.com/" target="_blank">https://www.fontspace.com/</a> <br>
                        </small>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="savef();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    //-----------------------------------------start
    function savef() {
        $('#fm').form('submit', {
            url: '<?= XROOT ?>inc/upload_fonts',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    msg('Success !', 'Berhasil di Save');
                    $('#edit').modal('hide');
                    window.location.reload();
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function hapus(font) {
        $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>Nama  Item : ' + font, function(r) {
            if (r) {
                $.post("<?= XROOT ?>inc/hapus_fonts", {
                    font
                }, function(result) {
                    if (result.success) {
                        msg('Success !', 'Berhasil Di Hapus');
                        window.location.reload();
                    } else {
                        msg('Error', result.errorMsg);
                    }
                }, 'json');
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#lb_id').html('UPLOAD Font [ Wajib Format ttf,otf]');
        document.getElementById("file").value = '';
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        $('#edit').modal('show');

    }
    //-----------------------------------------end
    $('#font_web_global_lb').show();
    $('#font_web_global').hide();
    $('#bt_s_font_web_global').hide();
    $('#bt_e_font_web_global').show();
    $('#rm_a_lb').show();
    $('#rm_a').hide();
    $('#bt_s_rm_a').hide();
    $('#bt_e_rm_a').show();
    //===========================================
    function pass_e(id) {
        $('#bt_e_' + id).hide();
        $('#bt_s_' + id).show();
        $('#' + id + '_lb').hide();
        $('#' + id).show();
        $('#' + id).focus();
    }
    //===========================================
    //===========================================
    function save(id) {
        var val = document.getElementById(id).value;
        var url = '<?= XROOT ?>inc/save_text2';
        $.post(url, {
            id,
            val
        }, function(result) {
            if (result.success) {
                document.getElementById(id + '_lb').innerHTML = '<strong>' + val + '</strong>';
                $('#' + id).hide();
                $('#' + id + '_lb').show();
                $('#bt_s_' + id).hide();
                $('#bt_e_' + id).show();
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    function status(id, act) {
        var url = '<?= XROOT ?>inc/status2';
        $.post(url, {
            id,
            act
        }, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Status berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
</script>