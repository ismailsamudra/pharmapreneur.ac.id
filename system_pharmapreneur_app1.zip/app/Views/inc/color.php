<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fa fa-paint-brush mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1-h">
                    <div class="col">
                        <small>
                            <strong>
                                WARNA QRCODE
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>DOT IN COLOR</small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="qrcode-a" onchange="ubah('qrcode-a')" value="<?= color('qrcode-a'); ?>">
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1-h">
                    <div class="col">
                        <small>
                            <strong>
                                WARNA PRIMARY <small class="float-right">Class :<strong> bg-1 , bg-1-h</strong> </small>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>BACKROUND COLOR</small>
                            <small>Class :<strong> pri-a</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="primary-a" onchange="ubah('primary-a')" value="<?= color('primary-a'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>TEXT COLOR</small>
                            <small>Class :<strong> pri-b</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="primary-b" onchange="ubah('primary-b')" value="<?= color('primary-b'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>HOVER COLOR</small>
                            <small>Class :<strong> pri-c</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="primary-c" onchange="ubah('primary-c')" value="<?= color('primary-c'); ?>">
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1-h">
                    <div class="col">
                        <small>
                            <strong>
                                WARNA SECONDARY <small class="float-right">Class :<strong> bg-2 , bg-2-h</strong> </small>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>BACKROUND COLOR</small>
                            <small>Class :<strong> sec-a</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="secondary-a" onchange="ubah('secondary-a')" value="<?= color('secondary-a'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>TEXT COLOR</small>
                            <small>Class :<strong> sec-b</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="secondary-b" onchange="ubah('secondary-b')" value="<?= color('secondary-b'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>HOVER COLOR</small>
                            <small>Class :<strong> sec-c</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="secondary-c" onchange="ubah('secondary-c')" value="<?= color('secondary-c'); ?>">
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-12 mb-2">
                <div class="card bg-1-h">
                    <div class="col">
                        <small>
                            <strong>
                                TOMBOL WIDGET <small class="float-right">Class :<strong> bt-1</strong> </small>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>BACKROUND COLOR</small>
                            <small>Class :<strong> bw-a</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="btn-wid-a" onchange="ubah('btn-wid-a')" value="<?= color('btn-wid-a'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>TEXT COLOR</small>
                            <small>Class :<strong> bw-b</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="btn-wid-b" onchange="ubah('btn-wid-b')" value="<?= color('btn-wid-b'); ?>">
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small>HOVER COLOR</small>
                            <small>Class :<strong> bw-c</strong> </small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="table-responsive">
                            <input type="color" class="form-control" id="btn-wid-c" onchange="ubah('btn-wid-c')" value="<?= color('btn-wid-c'); ?>">
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<script type="text/javascript">
    //===========================================
    function ubah(id) {
        var url = '<?= XROOT ?>inc/save_color';
        var warna = document.getElementById(id).value;
        $.post(url, {
            id,
            warna
        }, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Warna berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
</script>