<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
    <title>MAINTENANCE</title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/metro/easyui.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/icon.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/color.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <script src="<?= XROOT ?>script/easyui/jquery.min.js"></script>
    <script src="<?= XROOT ?>script/easyui/jquery.easyui.min.js"></script>
    <script src="<?= XROOT ?>script/easyui/datagrid-filter.js"></script>
    <script src="<?= XROOT ?>script/easyui/datagrid-detailview.js"></script>
    <script src="<?= XROOT ?>script/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/ui-sunny/easyui.css">
    <style>
        body {
            background-color: <?= color('primary-a') ?>;
            color: <?= color('primary-b') ?>;
        }

        .form_login {
            left: 50%;
            top: 50%;
            position: absolute;
            transform: translate(-50%, -50%);
        }

        @media only screen and (max-width: 600px) {
            /* .form_login {
                left: 0;
                top: 50%;
                position: absolute;
                transform: translate(-50%, -50%);
            } */
        }
    </style>
</head>

<body>
    <div class="form_login">
        <center>
            <img src="<?= XROOT ?>img/dev/maintenance.gif" width="240px" class="img-fluid">
            <br>
            SERVER MAINTENANCE
            <br>
            <div class="col">
                <br>
                Maaf ! Server Dalam Masa Perbaikan
                <br>
            </div>
            <br>
            <div class="card-footer">
                <a href="<?= XROOT ?>logout" class="btn-sm btn-dark d-block text-center mb-2">LOGOUT</a>
                <a href="" class="btn-sm btn-dark d-block text-center">RELOAD</a>
            </div>
        </center>
    </div>

    <script type="text/javascript">
        //=============================
        if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
            $.messager.show({
                title: 'Success',
                msg: '<?= session()->getFlashdata('info'); ?>'
            });
        }
        if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
            $.messager.show({
                title: 'Error',
                msg: '<?= session()->getFlashdata('error'); ?>'
            });
        }
        //=============================
    </script>
</body>

</html>