<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-android mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<style>
    .image_upload>input {
        display: none;
    }

    /* input[type=text]{width:220px;height:auto;} */
</style>
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    NB : KLICK LOGO UNTUK MENGGANTI.
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#edit" class="btn-sm bt-1 float-right mt-1" title="EDIT"><i class="fa fa-edit"></i></a></h5>
                                </x>
                                <div class="small">&nbsp;&nbsp;Extension : 'png','svg'</div>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="col">
                                <small>
                                    <strong>
                                        Logo Qrcode
                                    </strong>
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-6">
                        <center>
                            <span class="image_upload">
                                <label for="btn_logo_p">
                                    <a class="btn" rel="nofollow" id="btn_img">
                                        <div id="logo_p">
                                            <img src="<?= XROOT . 'img/instansi/' . inc("playstore-logo") ?>" width="100%">
                                        </div>
                                    </a>
                                </label>
                                <input type="file" name="btn_logo_p" id="btn_logo_p">
                            </span>
                        </center>
                    </div>
                </div>

            </div>
            <div class="col-md-10">
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Status
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="status" id="status1" onclick="status()" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="status" id="status2" onclick="status()" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Playstore Url
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("playstore-url") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            SDK NAME
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("sdk-name") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            SDK ID
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("sdk-id") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            SDK KEY
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("sdk-key") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Deskripsi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("playstore-desk") ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="_user"><i class="fa fa-edit mr-2"></i>Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">

                <form action="" method="post" enctype="multipart/form-data">

                    <div class="row">
                        <div class="col-md-6">
                            <small>Playstore Url</small>
                            <input type="url" class="form-control" name="playstore_url" value="<?= inc("playstore-url") ?>" required>
                            <small>SDK NAME</small>
                            <input type="text" class="form-control" name="sdk_name" value="<?= inc("sdk-name") ?>" required>
                        </div>
                        <div class="col-md-6">
                            <small>SDK ID</small>
                            <input type="text" class="form-control" name="sdk_id" value="<?= inc("sdk-id") ?>" required>
                            <small>SDK KEY</small>
                            <input type="text" class="form-control mb-2" name="sdk_key" value="<?= inc("sdk-key") ?>" required>
                        </div>
                        <div class="col-12">
                            <small>Deskripsi</small>
                            <textarea name="desk" id="desk" class="form-control" rows="4"><?= inc("playstore-desk") ?></textarea>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</button>
            </div>

            </form>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    var sts = "<?= inc('playstore-status') ?>";
    if (sts == 'true') {
        document.getElementById('status2').checked = false;
        document.getElementById('status1').checked = true;
    } else {
        document.getElementById('status1').checked = false;
        document.getElementById('status2').checked = true;
    }
    $('#desk').summernote({
        height: 240,
        // themes:paper,
        airMode: false
    })
    //===========================================
    function status() {
        var url = '<?= XROOT ?>inc/play_s';
        $.post(url, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Status berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    $(document).ready(function() {
        $('#btn_logo_p').on('change', function() {
            var url = '<?= XROOT ?>inc/upload_logo/playstore-logo';
            var property = document.getElementById('btn_logo_p').files[0];
            var image_name = property.name;
            var image_extension = image_name.split('.').pop().toLowerCase();
            var e = image_extension;
            if (e !== 'png' && e !== 'svg') {
                toastr.error('Logo Extensi Harus [ png , svg].');
                exit;
            }
            var form_data = new FormData();
            form_data.append("file", property);

            $.ajax({
                url: url,
                method: 'POST',
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    toastr.success('Logo Positife Berhasil Di Ganti.');
                    $('#logo_p').html(data);
                }
            });
        });
    });
    //===========================================
</script>