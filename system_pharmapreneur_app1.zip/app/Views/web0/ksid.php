<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <a href="<?= XROOT ?>web/ks" class="float-right"><i class="fa fa-arrow-left mr-2"></i>Semua Kerja Sama</a>
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">KERJA</span> SAMA</h2>
            <p class="large"><strong><?= $o->judul ?></strong></p>
        </div>
    </div>
</div>



<div class="section layout_padding">
    <div class="container">
        <?= (empty($o->content)) ? '<center><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>' : $o->content; ?>
        <br>
        <strong>Tgl Berlaku : <?= date("d-m-Y", strtotime($o->tgl_berlaku)) ?></strong> <br>
        <strong>Tgl Akhir : <?= date("d-m-Y", strtotime($o->tgl_akhir)) ?></strong> <br>
        <strong>Time Post :</strong> <?= $o->time ?><br>
        <strong>View :</strong> <?= $o->view ?>
    </div>
</div>

<!-- BODY END ------------------------------------------------------------->