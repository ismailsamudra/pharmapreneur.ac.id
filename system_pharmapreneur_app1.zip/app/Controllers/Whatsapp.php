<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Whatsapp extends BaseController
{
    public function __construct()
    {
        // (me()) ?: go();
    }
    private function dir()
    {
        return 'whatsapp/';
    }
    public function index()
    {
        go();
    }
    /**==============================================================
     *  whatsapp/happy_birthday START
    ===============================================================*/
    public function happy_birthday()
    {
        ck_uri();
        $this->part_in($this->dir() . 'birthday', '', 'Whatsapp birthday');
    }
    public function crud_birthday()
    {
        ck_uri('whatsapp/happy_birthday');
        $id = htmlspecialchars($_REQUEST['id']);
        $jam = htmlspecialchars($_REQUEST['jam']);
        $text = $_REQUEST['text'];
        $data_in = [
            'jam' => $jam,
            'text' => $text,
        ];
        update('engine', $data_in, ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_birthday()
    {
        ck_uri('whatsapp/happy_birthday');
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('engine')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('engine', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function del_birthday()
    {
        ck_uri('whatsapp/happy_birtday');
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('engine')->getWhere(['id' => $id], 1)->getRow();
        if ($o->file != null) {
            $path = FCPATH . '/file/wa_media/' . $o->file;
            (!fileExists($path)) ?: unlink($path);
        }
        update('engine', ['file' => ''], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_birthday()
    {
        ck_uri('whatsapp/happy_birthday');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'engine.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('engine', en64('sync="0"'));
        $country = db('engine')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(["sync" => "0"])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /**==============================================================
     *  whatsapp/happy_birthday END
    ===============================================================*/
    public function tes_kirim($db, $text)
    {
        $id = $_REQUEST['id'];
        $nomor = $_REQUEST['to'];
        $o = db($db)->getWhere(['id' => $id], 1)->getRow();
        if ($o->file == null) {
            ($o->$text == null) ?: $res = send_wa($nomor, $o->$text);
        } else {
            $path = FCPATH . '/file/wa_media/' . $o->file;
            if (file_exists($path)) {
                $res = send_img_wa($nomor, $o->file, $o->$text);
            } else {
                $res = send_wa($nomor, $o->$text);
            }
        }
        if ($res == 200) {
            echo json_encode(['success' => true]);
        } else if ($res == 421) {
            echo json_encode(['errorMsg' => 'API-KEY SALAH']);
        } else if ($res == 420) {
            echo json_encode(['errorMsg' => 'No.Hp Belum terdaftar Whatsapp']);
        } else if ($res == 500) {
            echo json_encode(['errorMsg' => 'Endpoint not Ready']);
        } else if ($res == 501) {
            echo json_encode(['errorMsg' => 'DEVICE / HP NO INTERNET']);
        } else {
            echo json_encode(['errorMsg' => 'Server Endpoint Error']);
        }
    }
    /**==============================================================
     *  whatsapp/broadcast START
    ===============================================================*/
    public function broadcast()
    {
        ck_uri();
        $this->part_in($this->dir() . 'broadcast', '', 'Whatsapp Broadcast');
    }
    public function paste_broadcast()
    {
        ck_uri('whatsapp/broadcast');
        $id = htmlspecialchars($_REQUEST['idcopy']);
        $akses = htmlspecialchars($_REQUEST['akses2']);
        $o = db('wa_broadcast')->getWhere(['id' => $id], 1)->getRow();
        $data_in = [
            'akses' => $akses,
            'jenis' => $o->jenis,
            'tgl' => $o->tgl,
            'jam' => $o->jam,
            'stamp' => $o->stamp,
            'text' => $o->text,
            'file' => $o->file,
        ];
        insert('wa_broadcast', $data_in);
        echo json_encode(['success' => true]);
    }
    public function crud_broadcast()
    {
        ck_uri('whatsapp/broadcast');
        $id = htmlspecialchars($_REQUEST['id']);
        $akses = htmlspecialchars($_REQUEST['akses']);
        $jenis = htmlspecialchars($_REQUEST['jenis']);
        $tgl = htmlspecialchars($_REQUEST['tgl']);
        $jam = htmlspecialchars($_REQUEST['jam']);
        $text = $_REQUEST['text'];
        if ($jenis == 'TIAP_HARI') {
            $stamp = date("His", strtotime($jam));
        } elseif ($jenis == 'TIAP_BULAN') {
            $stamp = date("d", strtotime($tgl)) . date("His", strtotime($jam));
        } elseif ($jenis == 'TIAP_TAHUN') {
            $stamp = date("md", strtotime($tgl)) . date("His", strtotime($jam));
        } else {
            $stamp = date("Ymd", strtotime($tgl)) . date("His", strtotime($jam));
        }
        $data_in = [
            'akses' => $akses,
            'jenis' => $jenis,
            'tgl' => $tgl,
            'jam' => $jam,
            'stamp' => $stamp,
            'text' => $text,
        ];
        if ($id == 'insert') {
            insert('wa_broadcast', $data_in);
        } else {
            update('wa_broadcast', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function status_broadcast()
    {
        ck_uri('whatsapp/broadcast');
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('wa_broadcast')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('wa_broadcast', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function del_broadcast()
    {
        ck_uri('whatsapp/broadcast');
        $id = htmlspecialchars($_REQUEST['id']);
        $data = htmlspecialchars($_REQUEST['data']);
        $o = db('wa_broadcast')->getWhere(['id' => $id], 1)->getRow();
        if ($o->file != null) {
            $cek = num_rows('wa_broadcast', en64('file="' . $o->file . '"'));
            if ($cek == 1) {
                $path = FCPATH . '/file/wa_media/' . $o->file;
                (!fileExists($path)) ?: unlink($path);
            }
        }
        if ($data == 'file') {
            update('wa_broadcast', ['file' => ''], ['id' => $id]);
        } else {
            delete('wa_broadcast', ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function get_broadcast()
    {
        ck_uri('whatsapp/broadcast');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'wa_broadcast.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('wa_broadcast', en64('id!="0"'));
        $country = db('wa_broadcast')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('text', $search)
            ->orLike('akses', $search)
            ->orLike('tgl', $search)
            ->orLike('id', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function auth_broadcast() //===PAGE AUTH===
    {
        // $data = json_decode(file_get_contents('php://input'), true);
        // $id = $data['id'];
        //========================= HAPPY BIRTHDAY START ==========================
        $datenow = date("m-d");
        $timenow = date("H:i");
        $secnow = date("s");
        $eng = db('engine')->getWhere(['sync' => '0', 'jam' => $timenow, 'sec' => $secnow, 'status' => 'true'])->getResult();
        foreach ($eng as $o) {
            $xx = db('users')->getWhere(['akses' => $o->akses])->getResult();
            foreach ($xx as $x) {
                $us = db($o->level)->getWhere(['id' => $x->id], 1)->getRow();
                if ($us->tanggal_lahir) {
                    $cek4 = num_rows($o->level, en64('tanggal_lahir="' . date("Y-", strtotime($us->tanggal_lahir)) . $datenow . '" AND status="true"'));
                    if ($cek4 > 0) {
                        if ($o->file == null) {
                            ($o->text == null) ?: send_wa($x->hp, $o->text);
                        } else {
                            $path = FCPATH . '/file/wa_media/' . $o->file;
                            if (file_exists($path)) {
                                send_img_wa($x->hp, $o->file, $o->text);
                            } else {
                                send_wa($x->hp, $o->text);
                            }
                        }
                    }
                }
            }
        }
        //========================== HAPPY BIRTHDAY END= ==========================
        //========================= TIAP HARI START ==========================
        $stamp_tiaphari = date("His");
        $cek3 = num_rows('wa_broadcast', en64('stamp="' . $stamp_tiaphari . '" AND status="true"'));
        if ($cek3 > 0) {
            $dt3 = db('wa_broadcast')->getWhere(['stamp' => $stamp_tiaphari])->getResult();
            foreach ($dt3 as $o) {
                $xx = db('users')->getWhere(['akses' => $o->akses])->getResult();
                foreach ($xx as $x) {
                    if ($o->file == null) {
                        ($o->text == null) ?: send_wa($x->hp, $o->text);
                    } else {
                        $path = FCPATH . '/file/wa_media/' . $o->file;
                        if (file_exists($path)) {
                            send_img_wa($x->hp, $o->file, $o->text);
                        } else {
                            send_wa($x->hp, $o->text);
                        }
                    }
                }
            }
        }
        //========================== TIAP HARI END= ==========================
        //========================= TIAP BULAN START ==========================
        $stamp_tiapbulan = date("dHis");
        $cek2 = num_rows('wa_broadcast', en64('stamp="' . $stamp_tiapbulan . '" AND status="true"'));
        if ($cek2 > 0) {
            $dt2 = db('wa_broadcast')->getWhere(['stamp' => $stamp_tiapbulan])->getResult();
            foreach ($dt2 as $o) {
                $xx = db('users')->getWhere(['akses' => $o->akses])->getResult();
                foreach ($xx as $x) {
                    if ($o->file == null) {
                        ($o->text == null) ?: send_wa($x->hp, $o->text);
                    } else {
                        $path = FCPATH . '/file/wa_media/' . $o->file;
                        if (file_exists($path)) {
                            send_img_wa($x->hp, $o->file, $o->text);
                        } else {
                            send_wa($x->hp, $o->text);
                        }
                    }
                }
            }
        }
        //========================== TIAP BULAN END= ==========================
        //========================= TIAP TAHUN START ==========================
        $stamp_tiaptahun = date("mdHis");
        $cek1 = num_rows('wa_broadcast', en64('stamp="' . $stamp_tiaptahun . '" AND status="true"'));
        if ($cek1 > 0) {
            $dt1 = db('wa_broadcast')->getWhere(['stamp' => $stamp_tiaptahun])->getResult();
            foreach ($dt1 as $o) {
                $xx = db('users')->getWhere(['akses' => $o->akses])->getResult();
                foreach ($xx as $x) {
                    if ($o->file == null) {
                        ($o->text == null) ?: send_wa($x->hp, $o->text);
                    } else {
                        $path = FCPATH . '/file/wa_media/' . $o->file;
                        if (file_exists($path)) {
                            send_img_wa($x->hp, $o->file, $o->text);
                        } else {
                            send_wa($x->hp, $o->text);
                        }
                    }
                }
            }
        }
        //========================== TIAP TAHUN END= ==========================
        //========================= HANYA SEKALI START ==========================
        $stamp_sekali = date("YmdHis");
        $cek = num_rows('wa_broadcast', en64('stamp="' . $stamp_sekali . '" AND status="true"'));
        if ($cek > 0) {
            $dt = db('wa_broadcast')->getWhere(['stamp' => $stamp_sekali])->getResult();
            foreach ($dt as $o) {
                $xx = db('users')->getWhere(['akses' => $o->akses])->getResult();
                foreach ($xx as $x) {
                    if ($o->file == null) {
                        ($o->text == null) ?: send_wa($x->hp, $o->text);
                    } else {
                        $path = FCPATH . '/file/wa_media/' . $o->file;
                        if (file_exists($path)) {
                            send_img_wa($x->hp, $o->file, $o->text);
                        } else {
                            send_wa($x->hp, $o->text);
                        }
                    }
                }
            }
        }
        //========================== HANYA SEKALI END= ==========================
    }
    /**==============================================================
     *  whatsapp/broadcast END
    ===============================================================*/
    public function status()
    {
        header('Content-Type: application/json', 'User-Agent:Get REST APi Response! - azka-wa!');
        $url = inc('wa_endpoint') . "status";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($httpcode == 200) {
            echo json_encode(['ready' => true]);
        } elseif ($httpcode == 201) {
            echo json_encode(['not_ready' => true]);
        } elseif ($httpcode == 501) {
            echo json_encode(['no_internet' => true]);
        } else {
            echo json_encode(['errorMsg' => 'PAGE 404']);
        }
        curl_close($curl);
    }
    /**==============================================================
     *  whatsapp/auto_reply START
    ===============================================================*/
    public function auto_reply()
    {
        ck_uri();
        $this->part_in($this->dir() . 'auto_reply', '', 'Whatsapp AutoReply');
    }
    public function crud_auto_reply()
    {
        ck_uri('whatsapp/auto_reply');
        $id = htmlspecialchars($_REQUEST['id']);
        $alias = htmlspecialchars($_REQUEST['alias']);
        $respon = $_REQUEST['respon'];
        $keyword = strtolower($alias);
        if ($id == 'insert') {
            $cek = num_rows('wa_reply', en64('keyword="' . $keyword . '"'));
            if ($cek > 0) {
                echo json_encode(['errorMsg' => 'Keyword sudah ada.']);
                exit;
            }
            $data_in = [
                'alias' => $alias,
                'keyword' => $keyword,
                'respon' => $respon,
            ];
            insert('wa_reply', $data_in);
        } else {
            $o = db('wa_reply')->getWhere(['id' => $id], 1)->getRow();
            if ($o->keyword != $keyword) {
                $cek = num_rows('wa_reply', en64('keyword="' . $keyword . '"'));
                if ($cek > 0) {
                    echo json_encode(['errorMsg' => 'Keyword sudah ada.']);
                    exit;
                }
            }
            $data_in = [
                'alias' => $alias,
                'keyword' => $keyword,
                'respon' => $respon,
            ];
            update('wa_reply', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function status_auto_reply()
    {
        ck_uri('whatsapp/auto_reply');
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('wa_reply')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('wa_reply', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function del_auto_reply()
    {
        ck_uri('whatsapp/auto_reply');
        $id = htmlspecialchars($_REQUEST['id']);
        $data = htmlspecialchars($_REQUEST['data']);
        $o = db('wa_reply')->getWhere(['id' => $id], 1)->getRow();
        if ($o->file != null) {
            $path = FCPATH . '/file/wa_media/' . $o->file;
            (!fileExists($path)) ?: unlink($path);
        }
        if ($data == 'file') {
            update('wa_reply', ['file' => ''], ['id' => $id]);
        } else {
            delete('wa_reply', ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function get_auto_reply0()
    {
        ck_uri('whatsapp/auto_reply');
        $result['total'] = "1";
        $country = db('wa_reply')->getWhere(['id' => '0'])->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_auto_reply()
    {
        ck_uri('whatsapp/auto_reply');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'wa_reply.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('wa_reply', en64('id!="0"'));
        $country = db('wa_reply')
            ->whereNotIn('id', ['0'])
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            // ->like('alias', $search)
            // ->orLike('respon', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /**==============================================================
     *  whatsapp/auto_reply END
    ===============================================================*/
    public function upload_media($db, $id)
    {
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            $name = $db . '_' . time() . '.' . $extension;
            $location = FCPATH . '/file/wa_media/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                $o = db($db)->getWhere(['id' => $id], 1)->getRow();
                if ($o->file != null) {
                    $cek = num_rows($db, en64('file="' . $o->file . '"'));
                    if ($cek == 1) {
                        $path = FCPATH . '/file/wa_media/' . $o->file;
                        (!fileExists($path)) ?: unlink($path);
                    }
                }
                update($db, ['file' => $name], ['id' => $id]);
                echo '<img src="' . XURL . $location . '" width="100%" />';
            }
        }
    }
    /**==============================================================
     * whatsapp/end_point  START
    ===============================================================*/
    public function end_point()
    {
        ck_uri();
        $this->part_in($this->dir() . 'end_point', '', 'Whatsapp Endpoint');
    }
    public function kuisioner()
    {
        ck_uri();
        $this->part_in($this->dir() . 'kuisioner', '', 'Whatsapp Kuisioner');
    }
    public function save_kuisioner()
    {
        ck_uri('whatsapp/kuisioner');
        $text = $_REQUEST['text'];
        update('temp_inc', ['code' => $text], ['id' => 'wa_kuisioner_text']);
        echo json_encode(['success' => true]);
    }
    public function qrcode()
    {
        ck_uri('whatsapp/end_point');
        header('Content-Type: application/json');
        $url = inc('wa_endpoint') . "qr";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $resp = curl_exec($curl);
        curl_close($curl);
        echo $resp;
    }
    public function me_data()
    {
        ck_uri('whatsapp/end_point');
        header('Content-Type: application/json');
        $url = inc('wa_endpoint') . "me_data";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $resp = curl_exec($curl);
        curl_close($curl);
        echo $resp;
    }
    public function logout()
    {
        ck_uri('whatsapp/end_point');
        $url = inc('wa_endpoint') . "logout";
        $token = inc('wa_key');;
        $data = ["token" => $token];
        $data = json_encode($data);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($httpcode == 200) {
            echo json_encode(['success' => true]);
        } else if ($httpcode == 421) {
            echo json_encode(['errorMsg' => 'API-KEY SALAH']);
        } else {
            echo json_encode(['errorMsg' => 'PAGE NOT FOUND']);
        }
        curl_close($curl);
    }
    public function auth_reply() //===PAGE AUTH===
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $nomor = $data['nomor'];
        $pesan = $data['pesan'];
        $id_pesan = $data['id_pesan']['id'];

        if (isset($nomor) && isset($pesan) && isset($id_pesan)) {
            $pesan = strtolower($pesan);
            $cek = num_rows('wa_reply', en64('keyword="' . $pesan . '" AND status="true"'));
            $nomor = filter_wa($nomor);
            if ($cek > 0) {
                $o = db('wa_reply')->getWhere(['keyword' => $pesan], 1)->getRow();
            } else {
                $o = db('wa_reply')->getWhere(['id' => '0'], 1)->getRow();
            }
            if ($o->status == 'true') {
                if ($o->file == null) {
                    ($o->respon == null) ?: send_wa($nomor, $o->respon);
                } else {
                    $path = FCPATH . '/file/wa_media/' . $o->file;
                    if (file_exists($path)) {
                        send_img_wa($nomor, $o->file, $o->respon);
                    } else {
                        send_wa($nomor, $o->respon);
                    }
                }
            }
        }
    }
    /**==============================================================
     * whatsapp/end_point  END
     ===============================================================*/
    public function send()
    {
        $number = $_REQUEST['to'];
        $number = $_REQUEST['to'];
        $msg = $_REQUEST['msg'];
        $res = send_wa($number, $msg);
        // echo json_encode(['errorMsg' => $res]);
        if ($res == 200) {
            echo json_encode(['success' => true]);
        } else if ($res == 421) {
            echo json_encode(['errorMsg' => 'API-KEY SALAH']);
        } else if ($res == 420) {
            echo json_encode(['errorMsg' => 'No.Hp Belum terdaftar Whatsapp']);
        } else if ($res == 500) {
            echo json_encode(['errorMsg' => 'Endpoint not Ready']);
        } else if ($res == 501) {
            echo json_encode(['errorMsg' => 'DEVICE / HP NO INTERNET']);
        } else {
            echo json_encode(['errorMsg' => 'Server Endpoint Error']);
        }
    }
}
