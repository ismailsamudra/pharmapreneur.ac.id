<?php

namespace App\Controllers;

class Portal extends BaseController
{
    public function index()
    {
        go();
    }
    public function g_pass()
    {
        $password = htmlspecialchars($_POST['pass_0']);
        $new_pass1 = htmlspecialchars($_POST['pass_1']);
        $new_pass2 = htmlspecialchars($_POST['pass_2']);
        pass_change($password, $new_pass1, $new_pass2);
    }
    public function login()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        save_session($username, $password);
    }
    public function reset_pass()
    {
        $otp = $_POST['otp'];
        reset_pass($otp);
    }
    public function get_otp()
    {
        $email = $_POST['email'];
        $hp = $_POST['hp'];
        get_otp($email, $hp);
    }
    public function regist()
    {
        $akses = htmlspecialchars($_REQUEST['akses']);
        $nama = htmlspecialchars($_REQUEST['nama']);
        $email = htmlspecialchars($_REQUEST['email']);
        $hp = htmlspecialchars($_REQUEST['hp']);
        $jk = htmlspecialchars($_REQUEST['jk']);
        save_regist($akses, $nama, $email, $hp, $jk);
    }
    public function get_users()
    {
        (me() == null) ? go() : '';
        $id = $_REQUEST['id'];
        $o = db('users')->getWhere(['id' => $id], 1)->getRow();
        echo json_encode($o);
    }
    public function get_regist()
    {
        (me() == null) ? go() : '';
        $id = $_REQUEST['id'];
        $o = db(inc('level_regist'))->getWhere(['id' => $id], 1)->getRow();
        echo json_encode($o);
    }
    public function get_reg($id)
    {
        (me() == null) ? go() : '';
        $o = db(inc('level_regist'))->getWhere(['id' => $id], 1)->getRow();
        echo json_encode($o);
    }
    public function get_dokter()
    {
        (me() == null) ? go() : '';
        $id = $_REQUEST['id'];
        $o = db(inc('level_dokter'))->getWhere(['id' => $id], 1)->getRow();
        echo json_encode($o);
    }
    public function save_inc_text()
    {
        (me() == null) ? go() : '';
        $id = htmlspecialchars($_REQUEST['id']);
        $val = $_REQUEST['val'];
        update('temp_inc', ['code' => $val], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function save_inc_bolean()
    {
        (me() == null) ? go() : '';
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('temp_inc')->getWhere(['id' => $id], 1)->getRow();
        $val = ($o->code == 'true') ? 'false' : 'true';
        update('temp_inc', ['code' => $val], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
}
