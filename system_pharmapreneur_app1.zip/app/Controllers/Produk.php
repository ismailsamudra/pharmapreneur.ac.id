<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Produk extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'produk/';
    }
    public function index()
    {
        go();
    }

    //========== produk/data START ===========
    public function data($id = null)
    {
        ck_uri('produk/data');
        if ($id == null) {
            $this->part_in($this->dir() . 'kategori', '', 'Setting data');
        } else {
            $data['id'] = $id;
            $this->part_in($this->dir() . 'data', $data, 'Setting data');
        }
    }
    // KATEGORI
    public function save_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $ket = $_REQUEST['ket'];
        $data_in = [
            'nama' => $nama,
            'ket' => $ket,
        ];

        if ($id == 'insert') {
            $data_in['id'] = time();
            $data_in['at_create'] = date("d-m-Y H:i:s");
            insert('produk_kategori', $data_in);
        } else {
            $data_in['at_update'] = date("d-m-Y H:i:s");
            update('produk_kategori', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        delete('produk_kategori', ['id' => $id]);
        $oo = db('produk_data')->getWhere(['kategori' => $id])->getResult();
        foreach ($oo as $o) {
            if ($o->img != null) {
                $path = FCPATH . 'img/web/produk/' . $o->img;
                (!file_exists($path)) ?: unlink($path);
            }
        }
        delete('produk_data', ['kategori' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_kategori')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('produk_kategori', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_kategori()
    {
        ck_uri('produk/data');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('produk_kategori');
        $country = db('produk_kategori')
            ->orderBy('id', 'ASC')
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    // DATA
    public function save_data($kategori)
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $url = $_REQUEST['url'];
        $new = $_REQUEST['new'];
        $unggul = $_REQUEST['unggul'];
        $data_in = [
            'nama' => $nama,
            'url' => $url,
            'new' => $new,
            'unggul' => $unggul,
        ];

        if ($id == 'insert') {
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/produk/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
            } else {
                echo json_encode(['errorMsg' => 'File Gambar Tidak di temukan.']);
                exit;
            }
            $data_in['kategori'] = $kategori;
            $data_in['at_create'] = date("d-m-Y H:i:s");
            insert('produk_data', $data_in);
        } else {
            $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/produk/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
                if ($o->img != null) {
                    $path = FCPATH . 'img/web/produk/' . $o->img;
                    (!file_exists($path)) ?: unlink($path);
                }
            }
            $data_in['at_update'] = date("d-m-Y H:i:s");
            update('produk_data', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_data()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/web/produk/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('produk_data', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_data()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('produk_data', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_data($id)
    {
        ck_uri('produk/data');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('produk_data', en64('kategori=' . $id));
        $country = db('produk_data')
            ->orderBy('id', 'DESC')
            ->where('kategori', $id)
            ->like('nama', $search)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //=========== produk/data END ============

    //========== produk/top START ===========
    public function top()
    {
        ck_uri();
        if (req()->getPost('web_produk_text_color') != null) {
            $web_produk_label = req()->getPost('web_produk_label');
            $web_produk_text_color = req()->getPost('web_produk_text_color');
            $web_produk_text_font = req()->getPost('web_produk_text_font');
            $web_produk_text_line_color = req()->getPost('web_produk_text_line_color');
            update('temp_inc', ['code' => $web_produk_label], ['id' => 'web_produk_label']);
            update('temp_inc', ['code' => $web_produk_text_color], ['id' => 'web_produk_text_color']);
            update('temp_inc', ['code' => $web_produk_text_font], ['id' => 'web_produk_text_font ']);
            update('temp_inc', ['code' => $web_produk_text_line_color], ['id' => 'web_produk_text_line_color ']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'top', '', 'Setting top');
    }
    //=========== produk/top END ============

}
